const express = require('express')
const app = express()
const port = 3000
const cors = require('cors')

var a=[
      {id: 1, name: 'Mario', address: "Hyderabad"},
      {id: 2, name: 'Max',   address: "Bangalore"},
      {id: 3, name: 'Kick',  address: "Chennai"},
      {id: 4, name: 'Adam',  address: "Delhi"},
      {id: 5, name: 'Mark',  address: "Mumbai"},
	  {id: 6, name: 'Tony',  address: "Mumbai"}
    ]
	
app.use(cors())
app.get('/', (req, res) =>{ 
console.log("called")
return res.send(a)
})

app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`))