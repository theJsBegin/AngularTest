import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'idAppender'
})
export class IdAppenderPipe implements PipeTransform {

  transform(value: string): string {
    return "ID"+value.toString().padStart(4,'O');
  }

}
