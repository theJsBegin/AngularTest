import { IdAppenderPipe } from './id-appender.pipe';

describe('IdAppenderPipe', () => {
  let pipe:IdAppenderPipe
  beforeEach(() => {
    pipe = new IdAppenderPipe();
  })

  it('create an instance', () => {
    const pipe = new IdAppenderPipe();
    expect(pipe).toBeTruthy();
  });

  it('pipe behaviour when value is 1 character',()=>{
    expect(pipe.transform('1')).toBe('IDOOO1')
  });

  it('pipe behaviour when value is 4 character',()=>{
    expect(pipe.transform('9999')).toBe('ID9999')
  });

  it('pipe behaviour when value is more than 4 character',()=>{
    expect(pipe.transform('99999')).toBe('ID99999')
  });

});
