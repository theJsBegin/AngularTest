import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeComponent } from './employee.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmployeeService } from 'src/app/services/employee.service';
import { MockEmployeeService } from 'src/app/services/employee.mock.service';
import { IdAppenderPipe } from 'src/app/pipes/id-appender.pipe';

describe('EmployeeComponent', () => {
  let component: EmployeeComponent;
  let fixture: ComponentFixture<EmployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [ EmployeeComponent, IdAppenderPipe ],
      providers: [ { provide: EmployeeService, useClass: MockEmployeeService }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('table should be rendered with the data and legnth of the data should be 5 ',()=>{
    component.ngOnInit();
    expect(component.empData.length).toBe(5);
  });

  it('check for the myValue() function call and show the value ',()=>{
    const myValueFunction = spyOn(component,'myValue').and.callThrough();
    const firstValue = fixture.debugElement.nativeElement.querySelector('td');
    firstValue.click();
    expect(myValueFunction).toHaveBeenCalled();
    expect(component.selectedValue).toEqual({id: 1, name: 'Mario', address: "Hyderabad"})
  });

  it('check for the myValue() function call, call reset function and check for value change ',()=>{
    const myValueFunction = spyOn(component,'myValue').and.callThrough();
    //calling method from html
    const firstValue = fixture.debugElement.nativeElement.querySelector('td');
    firstValue.click();
    expect(myValueFunction).toHaveBeenCalled();
    expect(component.selectedValue).toEqual({id: 1, name: 'Mario', address: "Hyderabad"})
    //calling method from component
    component.clearDetails();
    expect(component.selectedValue).toEqual(null);
  });

  it('check for the myValue() function call, call save function and check for save value ',()=>{
    const myValueFunction = spyOn(component,'myValue').and.callThrough();
    //calling method from html
    const firstValue = fixture.debugElement.nativeElement.querySelector('td');
    firstValue.click();
    expect(myValueFunction).toHaveBeenCalled();
    expect(component.selectedValue).toEqual({id: 1, name: 'Mario', address: "Hyderabad"})
    //calling method from componnent
    component.saveDetails();
    expect(component.savedValue).toEqual({id: 1, name: 'Mario', address: "Hyderabad"});
  });

  it('check for the call save function and check for save value ',()=>{
    //calling method from componnent
    component.saveDetails();
    expect(component.savedValue).toEqual(null);
  });

});
