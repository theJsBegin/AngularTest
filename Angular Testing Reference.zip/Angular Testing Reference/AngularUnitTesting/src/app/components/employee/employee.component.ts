import { Component, OnInit } from '@angular/core';
import { EmployeeService, Employee } from 'src/app/services/employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  selectedValue: Employee;
  savedValue: Employee;

  constructor(private empService:EmployeeService) { }

  empData:Employee[];

  ngOnInit(): void {
    this.empService.getEmployeeDetails().subscribe(data=>{
      this.empData=data;
      
    })
    
  }

  saveDetails(){
    this.savedValue=!!this.selectedValue?this.selectedValue:null;
  }

  clearDetails(){
    this.selectedValue=null
  }

  myValue(value){
    this.selectedValue=value
  }
}
