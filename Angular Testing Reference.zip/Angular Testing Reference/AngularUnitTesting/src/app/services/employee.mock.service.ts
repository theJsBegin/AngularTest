import { EmployeeService, Employee } from "./employee.service";
import { Observable } from 'rxjs/internal/Observable';
import { of } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class MockEmployeeService extends EmployeeService {
      public getEmployeeDetails():Observable<Employee[]>{
    let data=[
      {id: 1, name: 'Mario', address: "Hyderabad"},
      {id: 2, name: 'Max',   address: "Bangalore"},
      {id: 3, name: 'Kick',  address: "Chennai"},
      {id: 4, name: 'Adam',  address: "Delhi"},
      {id: 5, name: 'Mark',  address: "Mumbai"}
    ]
    return of(data);
  }
  }