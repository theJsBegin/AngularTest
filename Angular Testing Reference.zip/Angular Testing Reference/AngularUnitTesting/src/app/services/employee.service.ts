import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http: HttpClient) { }

  public getEmployeeDetails():Observable<Employee[]>{
    return this.http.get<Employee[]>("http://localhost:3000/")
  }

}

export interface Employee {
  name: string;
  address: string;
  id: number;
}
