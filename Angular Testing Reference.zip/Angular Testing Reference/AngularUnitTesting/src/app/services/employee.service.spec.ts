import { TestBed } from '@angular/core/testing';

import { EmployeeService, Employee } from './employee.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';


describe('EmployeeService', () => {
  let service: EmployeeService;
  let httpMock: HttpTestingController;
  
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [EmployeeService]
    });
    service = TestBed.inject(EmployeeService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
});

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be able to retrieve employees from the API as GET', () => {
    const dummyEmployees: Employee[] =[
      {id: 1, name: 'Mario', address: "Hyderabad"},
      {id: 2, name: 'Max',   address: "Bangalore"},
      {id: 3, name: 'Kick',  address: "Chennai"},
      {id: 4, name: 'Adam',  address: "Delhi"},
      {id: 5, name: 'Mark',  address: "Mumbai"}
     ];
    service.getEmployeeDetails().subscribe(employees => {
        expect(employees.length).toBe(5);
        expect(employees).toEqual(dummyEmployees);
    });
    const request = httpMock.expectOne('http://localhost:3000/');
    expect(request.request.method).toBe('GET');
    request.flush(dummyEmployees);
    });

  
});
